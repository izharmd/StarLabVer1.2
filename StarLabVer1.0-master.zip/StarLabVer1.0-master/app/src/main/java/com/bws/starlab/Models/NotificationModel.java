package com.bws.starlab.Models;

/**
 * Created by BWS on 24/05/2018.
 */

public class NotificationModel {

    String notificationBody;
    String getNotificationDate;
    String getNotificationTime;

    public String getNotificationBody() {
        return notificationBody;
    }

    public void setNotificationBody(String notificationBody) {
        this.notificationBody = notificationBody;
    }

    public String getGetNotificationDate() {
        return getNotificationDate;
    }

    public void setGetNotificationDate(String getNotificationDate) {
        this.getNotificationDate = getNotificationDate;
    }

    public String getGetNotificationTime() {
        return getNotificationTime;
    }

    public void setGetNotificationTime(String getNotificationTime) {
        this.getNotificationTime = getNotificationTime;
    }


}
