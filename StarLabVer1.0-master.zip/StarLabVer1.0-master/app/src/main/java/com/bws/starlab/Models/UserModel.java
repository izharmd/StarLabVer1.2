package com.bws.starlab.Models;

/**
 * Created by BWS on 30/05/2018.
 */

public class UserModel {

    String userName;
    String password;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }



}
