package com.bws.starlab.Models;

/**
 * Created by BWS on 23/05/2018.
 */

public class AssetsListModel {

   int equipId;

    String equipmentName;
    String equipModwl;
    String equipMrf;
    String equipDescription;


    public int getEquipId() {
        return equipId;
    }

    public void setEquipId(int equipId) {
        this.equipId = equipId;
    }

    public String getEquipmentName() {
        return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }

    public String getEquipModwl() {
        return equipModwl;
    }

    public void setEquipModwl(String equipModwl) {
        this.equipModwl = equipModwl;
    }

    public String getEquipMrf() {
        return equipMrf;
    }

    public void setEquipMrf(String equipMrf) {
        this.equipMrf = equipMrf;
    }

    public String getEquipDescription() {
        return equipDescription;
    }

    public void setEquipDescription(String equipDescription) {
        this.equipDescription = equipDescription;
    }




}
